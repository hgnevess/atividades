let novoElemento = document.createElement('p')
let texto = document.createTextNode('vai santos')

novoElemento.appendChild(texto)

let elementoAlvo = document.querySelector('#titulo-principal')
let delementoPai = document.querySelector('#container-principal')

elementoPai.insertBefore(novoElemento, elementoAlvo);