console.log(document.getElementsByTagName('h1'));
console.log(document.getElementsByTagName('div'));
console.log(document.getElementsByTagName('li'));

