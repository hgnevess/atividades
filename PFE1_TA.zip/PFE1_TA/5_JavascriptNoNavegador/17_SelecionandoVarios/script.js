let itens = document.querySelectorAll('.itens-vermelhos');
itens[0].style.color = 'red';

let itens3 = document.querySelectorAll('.itens-vermelhos');
itens[1].style.color = 'red';

let itens4 = document.querySelectorAll('.itens-vermelhos');
itens[2].style.color = 'red';





let itens2 = document.querySelectorAll('.itens-azuis');
console.log(itens2);

let itens5 = document.querySelectorAll('.itens itens-azuis');
itens[0].style.color = 'blue';
