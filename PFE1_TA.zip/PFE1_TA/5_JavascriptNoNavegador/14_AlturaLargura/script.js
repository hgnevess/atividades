let elemento = document.querySelector('#titulo-principal');
console.log('largura: ' + elemento.offsetWidth);
console.log('altura: ' + elemento.offsetHeight);

console.log('largura2: ' + elemento.clientWidth);
console.log('altura2: ' + elemento.clientHeight);
