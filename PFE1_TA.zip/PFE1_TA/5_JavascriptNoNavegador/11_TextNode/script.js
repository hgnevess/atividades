let pSemTexto = document.getElementById('sem-texto')
let texto = document.createTextNode('Inserir esse texto')
pSemTexto.appendChild(texto);