console.log(5 > 2 ? 'sim' : 'nao');
console.log(false ? 5 : 4);
console.log('Zé' == 'Zé' ? 'Ola. Zé' : 'Não é o Zé');