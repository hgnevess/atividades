console.log(5 > 3 && 3 == 2);
