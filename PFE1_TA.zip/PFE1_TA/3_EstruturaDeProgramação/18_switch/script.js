
let escolha = prompt("Escolha um lanche:").toLowerCase;

switch (escolha) {
    case "Lanche":
        console.log("Lanche");
        break;
    case "Bolo":
        console.log("Bolo Escolhido");
        break;
    default:
        console.log("Nao sei");
        break;
}