let idade = 16;
let nome = "Alessandro";
console.log(nome);
console.log(idade);
console.log(`O meu nome é ${nome}, e tenho ${idade} anos`);


