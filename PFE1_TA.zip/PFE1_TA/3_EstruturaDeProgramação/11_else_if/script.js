let nome = "Alessandro";
let idade = 18;

if (nome != undefined && nome == "Arelandro") {
    console.log("Nome está definido");
} else if (nome != undefined && nome.length > 10 && idade == 30){
    console.log("Meu nome é Alessandro");
} else {
    console.log("Não é Alessandro");
}


