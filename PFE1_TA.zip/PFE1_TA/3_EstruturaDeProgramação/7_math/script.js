let maior = Math.max(6,12,567,87,1243,435,345,3123);
console.log(maior);

let menor = Math.min(12,1,4,0,123,87);
console.log(menor);

let arredondar = Math.round(3.90);
console.log(arredondar);

let arredondaUp = Math.ceil(5.75);
console.log(arredondaUp);

let arredondaDown = Math.floor(5.99);
console.log(arredondaDown);


