// a
for (let i = 0; i < 11; i++) {
  console.log(i);
}

// b
for (let x = 10; x > 0; x--) {
  console.log(x);
}
