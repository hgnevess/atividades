let x = 20;
let y = 10;

let soma = x + y;
console.log(soma);

let subtracao = x - y;
console.log(subtracao);

let multiplicacao = x * y;
console.log(multiplicacao);

let divisao = x / y;
console.log(divisao);

let z = '5';
if (x == z) {
  console.log('number x string');
}

let v = true;
if (v == y) {
  console.log('boolean x number');
}

if (x == y) {
  console.log('iguais');
} else {
  console.log('ola');
}

if (x == z) {
  console.log('são iguais');
} else {
  console.log('nao sao nao');
}
// ==: Comparação com conversão de tipo (mais flexível).
// ===: Comparação sem conversão de tipo (mais rigoroso e seguro).

let passaporte = true;
if (x > 18 && passaporte == true) {
  console.log('pode viajar');
} else {
  console.log('pode não');
}

if (x > 50 || passaporte == true) {
  console.log('pode viajar');
} else {
  console.log('pode não');
}

if (x != 30) {
  console.log('é diferente');
}
