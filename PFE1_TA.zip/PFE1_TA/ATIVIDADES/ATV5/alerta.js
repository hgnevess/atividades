// a)

alert("Bem - Vindo")

// b)

let idade = prompt("Qual sua idade: ")
if (idade >= 18) {
   alert("Maior de idade")
} else {
    alert("Menor de idade")
}
