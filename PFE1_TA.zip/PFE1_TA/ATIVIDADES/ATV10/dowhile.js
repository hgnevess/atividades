// // a
// do {
//   var x = Number(prompt('Digite o número para saber seu dobro: '));
//   console.log(x*2);
// } while (x != 0);


// b
do {
  var nome = prompt('Nome:');
  console.log(nome);
} while (nome != 'sair');
