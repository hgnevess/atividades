// a
for (let i = 0; i < 11; i++) {
  if (i == 5) {
    break;
  }
}

// b
for (let x = 0; x < 11; x++) {
  if (x % 2 == 0) {
    console.log(x);
    continue;
  }
}
