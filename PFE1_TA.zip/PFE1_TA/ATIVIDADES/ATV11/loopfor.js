// a
// for (let i = 2; i < 20; i+=2) {
//   console.log(i);
// }

// b
var x = Number(prompt('Tabuada do:'))
for (let i = 0; i < 11; i++) {
  console.log(x + ' x ' + i + ' = ' + (x*i));
}
