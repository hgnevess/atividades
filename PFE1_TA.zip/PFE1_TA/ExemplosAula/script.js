// var titulo = document.getElementById("titulo")
// var conteudo = titulo.textContent

// console.log(conteudo)

function alterarCor(params) {
    document.body.style.backgroundColor = '#DAC8B3';
}

const botao = document.getElementById('meuBotao');
botao.addEventListener('click', alterarCor);