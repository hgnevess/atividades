let nome = 'julio';
console.log(typeof(nome));

let idade = 17;
console.log(typeof(idade));

let homem = true;
console.log(typeof(homem));

let infinito = undefined;
console.log(typeof(infinito));

let nullll = null;
console.log(typeof(nullll));

console.log('3' + 3 + 3 + '3' + 3);



