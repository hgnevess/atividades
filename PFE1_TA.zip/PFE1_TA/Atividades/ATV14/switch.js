// a
let x = Number(prompt('Digite um número correspondente ao dia da semana'));
switch (x) {
  case 1:
    console.log('Domingo');
    break;
  case 2:
    console.log('Segunda-Feira');
    break;
  case 3:
    console.log('Terça-Feira');
    break;
  case 4:
    console.log('Quarta-Feira');
    break;
  case 5:
    console.log('Quinta-Feira');
    break;
  case 6:
    console.log('Sexta-Feira');
    break;
  case 7:
    console.log('Sábado');
    break;
  default:
    console.log('Digite um número de 1-7');
    break;
}



// b
let cor = prompt('Escolha uma cor: ')
switch (cor) {
  case 'Azul':
    console.log('oceano dos seus olhos');
    break;
  case 'Vermelho':
    console.log('vermelho vulcânico igual ao meu amor por ti');
    break;
  case 'Verde':
    console.log('campos que se estendem ao horizonte da ingleterra medieval');
    break;
  case 'Amarelo':
    console.log('tu que és radiante como sol');
    break;
  default:
    break;
}
