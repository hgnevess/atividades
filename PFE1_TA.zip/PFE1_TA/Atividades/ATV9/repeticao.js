let contador = 0;
while (contador <= 10) {
  console.log(contador++);
}

let x = Number(prompt('Digite a senha: '));
while (x != 1234) {
  x = Number(prompt('Digite a senha:'));
  if (x == 1234) {
    console.log('Senha correta!');
    break;
  }
}


