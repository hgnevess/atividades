let consoleTeste = () => {
  console.log("Olá");
};
consoleTeste();

let somaDoisNumeros = (num,num2) => {
  console.log("A soma dos numeros são: " + (num + num2));
  // return a + b
}
somaDoisNumeros(5,2)
// console.log(soma(7,7))