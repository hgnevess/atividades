function adicionarValor(valor) {
    document.getElementById("display").value += valor;
  }

  function calcularResultado() {
    const display = document.getElementById("display");
    try {
      display.value = eval(display.value);  // eval() calcula a expressão
    } catch (error) {
      display.value = 'Erro';
    }
  }

  function limparDisplay() {
    document.getElementById("display").value = '';
  }