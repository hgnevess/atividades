// Exercício 1) Criar uma função para alterar o conteúdo de um parágrafo (Botão)

function alterarConteudo(params) {
    const paragrafo = document.getElementById('paragrafo');
    paragrafo.textContent = 'Sim!'
}
const button = document.getElementById('botao')
button.addEventListener('click', alterarConteudo)