// Exercício 2) Crie uma hierarquia da sua família utilizando os conceitos de DOM.

function destacarElemento(params) {
    let neto1 = document.getElementById('neto1');
    neto1.style.color = 'blue'
}
