function aumentar() {
    var botao = document.getElementById('botao');

    var largura = botao.offsetWidth;
    var altura = botao.offsetHeight;
   
    botao.style.width = (largura*2) + 'px';
    botao.style.height = (altura*2) + 'px';
}
